# Employee Management REST API

A fully functional CRUD REST API built with **Spring Boot 3.2**, **Spring Data JPA**, and **H2 in-memory database**.

## Tech Stack
- Java 17
- Spring Boot 3.2.4
- Spring Web + Spring Data JPA
- Jakarta Bean Validation
- H2 In-Memory Database
- Lombok
- Maven

## API Endpoints

| Method | URL | Description | Status Code |
|--------|-----|-------------|-------------|
| GET | /api/v1/employees | Get all employees | 200 OK |
| GET | /api/v1/employees/{id} | Get employee by ID | 200 / 404 |
| POST | /api/v1/employees | Create new employee | 201 Created |
| PUT | /api/v1/employees/{id} | Update employee | 200 OK |
| DELETE | /api/v1/employees/{id} | Delete employee | 204 No Content |

## How to Run

```bash
# Clone the repo
git clone https://github.com/amitkununayak/empolyee-api.git
cd empolyee-api

# Run the app
mvn spring-boot:run
```

App runs at: `http://localhost:8080`  
H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:employeedb`, Username: `sa`, Password: empty)

## Sample Request (POST)

```json
{
  "firstName": "Amit",
  "lastName": "Kununayak",
  "email": "amit@example.com",
  "department": "Engineering",
  "designation": "Software Engineer",
  "salary": 75000.00,
  "joiningDate": "2024-01-15",
  "status": "ACTIVE"
}
```

## Sample curl Commands

```bash
# Create employee
curl -X POST http://localhost:8080/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Amit","lastName":"Kununayak","email":"amit@example.com","department":"Engineering","designation":"Software Engineer","salary":75000.00,"joiningDate":"2024-01-15","status":"ACTIVE"}'

# Get all employees
curl http://localhost:8080/api/v1/employees

# Get by ID
curl http://localhost:8080/api/v1/employees/1

# Update employee
curl -X PUT http://localhost:8080/api/v1/employees/1 \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Amit","lastName":"Kununayak","email":"amit@example.com","department":"Engineering","designation":"Senior Engineer","salary":90000.00,"joiningDate":"2024-01-15","status":"ACTIVE"}'

# Delete employee
curl -X DELETE http://localhost:8080/api/v1/employees/1
```
