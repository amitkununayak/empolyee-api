package com.riya.employeeapi.exception;

import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse {
    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String path;
    private List<String> errors;

    public static ErrorResponse of(int status, String message, String path) {
        return ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(status)
                .error(status == 404 ? "Not Found" : status == 409 ? "Conflict" : "Error")
                .message(message)
                .path(path)
                .build();
    }

    public static ErrorResponse ofValidation(int status, List<String> errors, String path) {
        return ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(status)
                .error("Bad Request")
                .message("Validation failed")
                .path(path)
                .errors(errors)
                .build();
    }
}
