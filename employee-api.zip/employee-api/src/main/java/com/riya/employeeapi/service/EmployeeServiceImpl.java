package com.riya.employeeapi.service;

import com.riya.employeeapi.dto.EmployeeRequestDTO;
import com.riya.employeeapi.dto.EmployeeResponseDTO;
import com.riya.employeeapi.exception.DuplicateEmailException;
import com.riya.employeeapi.exception.ResourceNotFoundException;
import com.riya.employeeapi.mapper.EmployeeMapper;
import com.riya.employeeapi.model.Employee;
import com.riya.employeeapi.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository repository;
    private final EmployeeMapper mapper;

    @Override
    public List<EmployeeResponseDTO> getAllEmployees() {
        return repository.findAll()
                .stream()
                .map(mapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public EmployeeResponseDTO getEmployeeById(Long id) {
        Employee emp = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        return mapper.toResponseDTO(emp);
    }

    @Override
    public EmployeeResponseDTO createEmployee(EmployeeRequestDTO dto) {
        if (repository.existsByEmail(dto.getEmail())) {
            throw new DuplicateEmailException("Email already in use: " + dto.getEmail());
        }
        Employee saved = repository.save(mapper.toEntity(dto));
        return mapper.toResponseDTO(saved);
    }

    @Override
    public EmployeeResponseDTO updateEmployee(Long id, EmployeeRequestDTO dto) {
        Employee existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        if (!existing.getEmail().equals(dto.getEmail()) && repository.existsByEmail(dto.getEmail())) {
            throw new DuplicateEmailException("Email already in use: " + dto.getEmail());
        }
        mapper.updateEntityFromDTO(dto, existing);
        return mapper.toResponseDTO(repository.save(existing));
    }

    @Override
    public void deleteEmployee(Long id) {
        Employee emp = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        repository.delete(emp);
    }
}
