package com.riya.employeeapi.dto;

import com.riya.employeeapi.model.Employee.EmploymentStatus;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;

/**
 * DTO used for CREATE and UPDATE requests.
 * Validation annotations ensure bad data never reaches the service layer.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeRequestDTO {

    @NotBlank(message = "First name is required")
    @Size(min = 2, max = 50, message = "First name must be between 2 and 50 characters")
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(min = 2, max = 50, message = "Last name must be between 2 and 50 characters")
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    private String email;

    @NotBlank(message = "Department is required")
    private String department;

    @NotBlank(message = "Designation is required")
    private String designation;

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Salary must be greater than 0")
    @DecimalMax(value = "10000000.0", message = "Salary must be less than 10,000,000")
    private Double salary;

    private LocalDate joiningDate;

    private EmploymentStatus status;
}
